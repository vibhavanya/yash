def validEmplyoee(mid,sal):
    if(len(mid)==8 and mid[0]=='M'):
        if(sal>0):
            sal=sal+((20/100)*sal)
        else:
            print("Invalid Salary")
    else:
        print("Invalid M-Id")
    return mid,int(sal)

mid=input("Enter M-id")
sal=int(input("Enter Salary"))
mid,sal=validEmplyoee(mid,sal)
print("EmployeeId={}".format(mid))
print("Salary={}".format(sal))