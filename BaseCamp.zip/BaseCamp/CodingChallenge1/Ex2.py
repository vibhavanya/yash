def triangelArea(height,base):
    return (height*base)//2

def rectangleArea(length,width):
    return length*width

def circleArea(radius):
    return (3.142*radius*radius)
while(1):
    print("1-Area of Triange\n2-Area of Rectange\n3-Area of Circle\n4-Exit\n")
    n=int(input("Enter your choice"))
    if(n==1):
        h=int(input())
        b=int(input())
        print("Area of Triangle={}".format(triangelArea(h,b)))
    if(n==2):
        l=int(input())
        w=int(input())
        print("Area of Rectangle={}".format(rectangleArea(l,w)))

    if(n==3):
        r=int(input())
        print("Area of Circle={}".format(circleArea(r)))
    if(n==4):
        exit()

