st="aa bb ccdc dc"
n=st.count("dc")
print(n)

def count(st,key):
    len()
    for i in st:
