s_id=int(input("Enter Number of List"))
r=int(input("Enter Element into List"))

a=[[int(input()) for i in range(r)] for j in range(s_id)]