row=int(input())
col=int(input())
a=[[int(input()) for i in range(col)] for j in range(row)]
print(a)

b=[[int(input()) for i in range(col)] for j in range(row)]
print(b)

def MatrixSum(a,b,row,col):
    sum1=0
    sum2=0
    for i in range(row):
        for j in range(col):
            sum1+=a[i][j]

    for i in range(row):
        for j in range(col):
            sum2+=b[i][j]

    return sum1+sum2

#print(MatrixSum(a,b,row,col))


def firstColInsertion(a,row,col):
    l=[]
    for i in range(row):
        temp=a[i][0]
        l.append(temp)
    insertionSort(l)
    print(l)

#firstColInsertion(a,row,col)

def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key

def bubbleSort(l):
    for i in range(len(l)):
        for j in range(len(l)-i-1):
            if(l[j]>l[j+1]):
                l[j],l[j+1]=l[j+1],l[j]


def lastSecondColBubble(b,row,col):
    l=[]
    for i in range(row):
        temp=b[i][row-1]
        l.append(temp)
    bubbleSort(l)
    print(l)

lastSecondColBubble(b,row,col)


def joinTwoArrays(a,b,row,col):
    arr1=[]
    arr2=[]
    mat=[]
    for i in range(row):
        for j in range(col):
            arr1.append(a[i][j])
            arr2.append(b[i][j])
    mat=arr1+arr2
    print(mat)
    insertionSort(mat)
    key=int(input("Enter Key"))
    print(binarySearchElement(mat,key))

def binarySearchElement(b,key):
    l=0
    h=len(b)-1

    while(l<=h):
        mid=(h+l)//2
        if(b[mid]>key):
            h=mid-1
        elif(b[mid]<key):
            l=mid+1
        elif(b[mid]==key):
            return True
    else:
        return False

#joinTwoArrays(a,b,row,col)

def diagonalShift(a,b,row,col):
    for i in range(row):
        for j in range(col):
            if (i==j):
                temp=a[i][j]
                a[i][j]=b[i][j]
                b[i][j]=temp
            '''
            elif(i+j==row-1):
                temp=a[i][j]
                a[i][j]=b[i][j]
                b[i][j]=temp
            '''ssss


    print(a)
    print(b)



while(1):
    print("1-Matrix Sum\n2-Diagonal Shift\n3-Sort Last Column of 2nd Matrix\n4-Sort First Column of 1st Matrix\n5-Join Two Matrix and Search Element\n6-Exit\n")
    ch=int(input("Enter Your Choice"))
    if(ch==1):
        print(MatrixSum(a,b,row,col))
    elif(ch==2):
        diagonalShift(a,b,row,col)
    elif(ch==3):
        lastSecondColBubble(b,row,col)
    elif(ch==4):
        firstColInsertion(a,row,col)
    elif(ch==5):
        joinTwoArrays(a,b,row,col)
    elif(ch==6):
        exit()

