'''


dist=21
max=5
exp=2
n=0
res=0
d=0

while(n<=dist):
    a=int(input())
    d+=1
    if(a>5 and exp!=0):
        res+=a
        exp=exp-1
        n+=a
        print("n"+str(n))
    else:
        res+=a
        n+=a
        print("n"+str(n))
    if(n==dist):
        break

print("Travel Days="+str(d))

dist=21
max=5
exp=2
n=0
res=0
d=0
'''

dist=int(input("Enter distance from two cities"))
max=int(input("Maximum distance travlled in a Day"))
exp=int(input("Number of Exception Day"))
n=0
d=0
res=0
l=[]
k=[]
r=0
for i in range(exp):
    ex=int(input("Enter Exp"))
    km=int(input("Enter KM"))
    l.append(ex)
    k.append(km)
#print(l)
#print(k)
while(n<=dist):
    d+=1
    #print(d)
    if((d in l) and (exp!=0)):
        #for i in range(len(k)):
        #a=int(input("Enter km"))
        res+=k[r]
        n+=k[r]
        exp-=1
        r+=1
        #print(str(d)+" "+str(res))
    else:
        res=res+max
        n+=max
        #print("n"+str(n))
        #print(res)
    if(n==dist):
        break

print("Travel Days="+str(d))
