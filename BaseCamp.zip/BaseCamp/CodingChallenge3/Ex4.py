def floor(st):
    if(st=="0"):
        return "GF"
    elif(st=="1"):
        return "1F"
    elif(st=="2"):
        return "2F"
    else:
        return "Invalid Floor"
        exit()

def CrMr(st):
    if st=="CR":
        return "CR"
    elif st=="MR":
        return "MR"
    else:
        return "Invalid Room"
        exit()


st=input("Enter CR/MR")
if(CrMr(st)!=st):
    exit()
f=input("Enter Floor")
r=input("Enter Room Number")
lc="LC1"
res="MTK"+"-"+CrMr(st)+"-"+"LC1"+"-"+floor(f)+"-"+r
print("The Generated Room Number is {}.".format(res))


