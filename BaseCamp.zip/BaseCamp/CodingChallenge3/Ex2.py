n=int(input())
for i in range(n,0,-1):
    r=1
    for j in range(i):
        print(" ",end=" ")
    for k in range(n-i+1):
        print(r,end=" ")
        r+=1
    print()
