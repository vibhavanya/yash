def isUpper(st):
    cnt=0
    for i in range(len(st)):
        if(st[i]>='A' and st[i]<='Z'):
            cnt+=1
    if(cnt==len(st)):
        return True
    else:
        return False


def isLower(st):
    cnt=0
    for i in range(len(st)):
        if(st[i]>='a' and st[i]<='z'):
            cnt+=1
    if(cnt==len(st)):
        return True
    else:
        return False

l=[]
r=int(input("Enter Range of an Array"))
for i in range(r):
    l.append(input())
cnt=0
print(l)
upper=[]
lower=[]
mixed=[]
for st in l:
    if(isUpper(st)==True):
        upper.append(st)
    elif(isLower(st)==True):
        lower.append(st)
    else:
        mixed.append(st)
print("UpperCase: {}".format(upper))
print("LowerCase: {}".format(lower))
print("Mixed: {}".format(mixed))



