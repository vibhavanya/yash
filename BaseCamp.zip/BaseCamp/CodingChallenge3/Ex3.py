def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key

def joinTwoArrays(a,b,row,col):
    arr1=[]
    arr2=[]
    mat=[]
    for i in range(row):
        for j in range(col):
            arr1.append(a[i][j])
            arr2.append(b[i][j])

    #mat=arr1+arr2
    c=[[a[i][j]+b[i][j] for j in range(col)] for i in range(row)]
    print(c)
    for i in range(row):
        for j in range(col):
            mat.append(c[i][j])
    print(mat)

    insertionSort(mat)
    key=int(input("Enter Key"))
    print(binarySearchElement(mat,key))

def binarySearchElement(b,key):
    l=0
    h=len(b)-1

    while(l<=h):
        mid=(h+l)//2
        if(b[mid]>key):
            h=mid-1
        elif(b[mid]<key):
            l=mid+1
        elif(b[mid]==key):
            return True
    else:
        return False
row=int(input())
col=int(input())
a=[[int(input()) for i in range(col)] for j in range(row)]
print(a)

b=[[int(input()) for i in range(col)] for j in range(row)]
print(b)

joinTwoArrays(a,b,row,col)