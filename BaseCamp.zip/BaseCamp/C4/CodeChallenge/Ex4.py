def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key

def joinTwoArraysCols(a,b,row,col):
    arr1=[]
    arr2=[]
    mat=[]
    for i in range(row):
            arr1.append(a[i][row-1])
            arr2.append(b[i][col-1])
    mat=arr1+arr2
    return mat
row=int(input())
col=int(input())
a=[[input() for i in range(col)] for j in range(row)]
print(a)

b=[[input() for i in range(col)] for j in range(row)]
print(b)

mergeCols=joinTwoArraysCols(a,b,row,col)
insertionSort(mergeCols)
print(mergeCols)
