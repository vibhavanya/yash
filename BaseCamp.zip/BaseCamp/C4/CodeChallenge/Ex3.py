#1st row of 1st matrix 2nd row of 2nd matrix
#sum is present in any of the matrix using binary search
def binarySearchElement(b,key):
    l=0
    h=len(b)-1

    while(l<=h):
        mid=(h+l)//2
        if(b[mid]>key):
            h=mid-1
        elif(b[mid]<key):
            l=mid+1
        elif(b[mid]==key):
            return True
    else:
        return False

def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key

def Sum(l):
    sum=0
    for i in l:
        sum+=i
    return sum
def firstMatrixRow(a,row,col):
    l=[]
    for i in range(row):
        temp=a[0][i]
        l.append(temp)
    return l

def SecondMatrixCol(a,row,col):
    l=[]
    for i in range(row):
        temp=a[1][i]
        l.append(temp)
    return l
def joinTwoArrays(a,b,row,col):
    arr1=[]
    arr2=[]
    mat=[]
    for i in range(row):
        for j in range(col):
            arr1.append(a[i][j])
            arr2.append(b[i][j])
    mat=arr1+arr2
    return mat

row=int(input())
col=int(input())
m=[]
a=[[int(input()) for i in range(col)] for j in range(row)]
print(a)

b=[[int(input()) for i in range(col)] for j in range(row)]
print(b)

m1=firstMatrixRow(a,row,col)
m2=SecondMatrixCol(b,row,col)
merge=joinTwoArrays(a,b,row,col)

for r in range(0,row):
    mul=m1[r]*m2[r]
    m.append(mul)

#print(m1)
#print(m2)
print(m)
key=Sum(m)
print(merge)
insertionSort(merge)
print(binarySearchElement(merge,key))
