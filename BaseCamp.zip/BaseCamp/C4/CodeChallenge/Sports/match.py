class Match:
    def __init__(self,mid,mname,mdate,team1,team2,totalcrowd):
        self.mid=mid
        self.mname=mname
        self.mdate=mdate
        self.team1=team1
        self.team2=team2
        self.totalcrowd=totalcrowd

    def getMatch(self):
        return [self.mid,self.mname,self.mdate,self.team1,self.team2,self.totalcrowd]
