from C4.CodeChallenge.Sports.match import Match as Match
from C4.CodeChallenge.Sports.venue import Venue as ven

mats=[]
def addMatches(mats):
    vid=int(input("Enter Venue ID"))
    vname=input("Enter Venue Name")
    vcity=input("Enter Venue City")
    crowdcapacity=int(input("Enter Crowd Capacity"))
    mid=int(input("Enter Match ID"))
    mname=input("Enter Match Name")
    mdate=input("Enter Matc Date")
    t1=input("Enter Team1")
    t2=input("Enter Team2")
    validateVenue(vname,mdate)
    validateteam(t1,mdate)
    if(t2==t1):
        print("Same Team Cannot be Done")
        exit()
    totalcrowd=int(input("Enter Total crowd"))
    if(totalcrowd<=crowdcapacity):
        totalcrowd=totalcrowd
    else:
        print("Invalid Input")
        exit()
    mats.append(ven(vid,vname,vcity,crowdcapacity,Match(mid,mname,mdate,t1,t2,totalcrowd)))
    return mats

def findMatchesDate(mats):
    pdate=input("Enter Particular Date")
    for i in range(len(mats)):
        if(pdate==mats[i].match.mdate):
            print(mats[i].match.getMatch())

def findMatchTeam(mats):
    pteam=input("Enter Team to get Venue")
    for i in range(len(mats)):
        if(pteam==mats[i].match.team1 or pteam==mats[i].match.team2):
            print(mats[i].getVenue())


def displayCapacity(mats):
    for i in range(len(mats)):
        for j in range(len(mats)-i-1):
            if(mats[j].crowdcapacity>mats[j+1].crowdcapacity):
                mats[j],mats[j+1]=mats[j+1],mats[j]
    for i in range(len(mats)):
        print(mats[i].getVenue())


def totalRevenue(mats):
    city=input("Enter a City")
    rev=0
    for i in range(len(mats)):
        if(city=="Banglore"):
            rev=mats[i].match.totalcrowd*700
        elif(city=="Mumbai"):
            rev=mats[i].match.totalcrowd*800
        elif(city=="Chennai"):
            rev=mats[i].match.totalcrowd*900
        elif(city=="Dharmashal"):
            rev=mats[i].match.totalcrowd*1000
    print("Total Revenue is:",rev)
def validateteam(team,date):
    for i in range(len(mats)):
        if((team==mats[i].match.team1 or team==mats[i].match.team2 and mats[i].match.mdate==date)):
            print("Error")
            exit()
def validateVenue(vname,date):
    for i in range(len(mats)):
        if(mats[i].vname==vname and mats[i].match.mdate==date):
            print("Invalid")
            exit()

while True:
    print("1-Add Matches\n2-Find All Matches in particular Day\n3-Find Venues for a Match for Particular Team\n4-Display all Venues in order of Capacity\n5-Calculate Revenue for Particular City\n6-Exit\n")
    ch=int(input("Enter Your Choice"))
    if(ch==1):
        rn=int(input("Enter Number of Matches"))
        for i in range(rn):
            addMatches(mats)
    elif(ch==2):
        findMatchesDate(mats)
    elif(ch==3):
         findMatchTeam(mats)
    elif(ch==4):
        displayCapacity(mats)
    elif(ch==5):
        totalRevenue(mats)
    elif(ch==6):
        exit()
