class Venue:
    def __init__(self,vid,vname,vcity,crowdcapacity,match):
        self.vid=vid
        self.vname=vname
        self.vcity=vcity
        self.crowdcapacity=crowdcapacity
        self.match=match

    def getVenue(self):
        [mid,mname,date,team1,team2,totalcrowd]=self.match.getMatch()
        return [self.vid,self.vname,self.vcity,self.crowdcapacity,mid,mname,date,team1,team2,totalcrowd]




