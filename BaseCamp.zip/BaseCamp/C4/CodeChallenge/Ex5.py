class Movie:
    def __init__(self,id,name,rating,type,collection):
        self.id=id
        self.name=name
        self.rating=rating
        self.type=type
        self.collection=collection

    def display(self):
        print("MovieId= {}\nName= {}\nRating= {}\nType= {}\nCollection={}\n".format(self.id,self.name,self.rating,self.type,str(self.collection)+"cr"))


