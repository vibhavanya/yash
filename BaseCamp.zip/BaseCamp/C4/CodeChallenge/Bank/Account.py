class Account:
    def __init__(self,id,type,balance,customer):
        self.id=id
        self.type=type
        self.balance=balance
        self.customer=customer
    def getAccount(self):
        [cid,cname,cage,csal]=self.customer.getCustomer()
        return [self.id,self.type,self.balance,cid,cname,cage,csal]
