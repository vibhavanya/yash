from C4.CodeChallenge.Bank.Account import Account as acc
from C4.CodeChallenge.Bank.customer import Customer as cust
bank=[]
def addCustomer(bank):
    aid=input("Enter Account ID:")
    atype=input("Enter Account Type:")
    balance=float(input("Enter Balance:"))
    cid=int(input("Enter Customer Id:"))
    cname=input("Enter Customer Name:")
    cage=int(input("Enter Age of Customer"))
    csal=float(input("Enter Salary of Customer"))
    bank.append(acc(aid,atype,balance,cust(cid,cname,cage,csal)))
    return bank
def cutomerDetailDisplay(bank):
    for i in range(len(bank)):
        cid,cname,cage,csal=bank[i].customer.getCustomer()
        print("CustomerID: {}\nCustomerName= {}\nCustomerAge= {}\nCustomerSal= {}".format(cid,cname,cage,csal))

def balance5k(bank):
    for i in range(len(bank)):
        aid,atype,bal,cid,cname,cage,csal=bank[i].getAccount()
        if(bal>=5000):
            print("AccountID: {}\n AccountType: {}\nBalance: {}\nCustomerID: {}\nCustomerName= {}\nCustomerAge= {}\nCustomerSal= {}".format(aid,atype,bal,cid,cname,cage,csal))
while True:
    print("1-ADD Customer\n2-Customer Details Display\n3-Balance Greater>= 5K\n4-Exit\n")
    ch=int(input("Enter Your Choice"))
    if(ch==1):
        addCustomer(bank)
    elif(ch==2):
        cutomerDetailDisplay(bank)
    elif(ch==3):
        balance5k(bank)
    elif(ch==4):
        print("Thank You!!")
        exit()


