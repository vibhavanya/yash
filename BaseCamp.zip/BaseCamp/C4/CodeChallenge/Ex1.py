def splitString(a,dem):
    word=[]
    cnt=0
    for i in range(len(a)):
        if(a[i]==dem):
            word.append(a[cnt:i])
            cnt=i+1
    word.append(a[cnt:len(a)])
    return word
def reverse(st):
    return st[::-1]

def ReverseEven(l):
    for i in range(len(l)):
        if((i+1)%2==0):
            l[i]=reverse(l[i])
    return l

def stringConvert(l):
    st=""
    for i in l:
        st+=i
        st+=" "
    return st


def Replace(st):
    for i in st:
        if(i=='a' or i=='e' or i=='i' or i=='o' or i=='u'):
            st=st.replace(i,"#")
        elif(i==" "):
            pass
        else:
            st=st.replace(i,chr(ord(i)-1))
    return st

st=input("Enter a String")
rev=splitString(st," ")
#print(rev)
res=ReverseEven(rev)
#print(res)
st1=stringConvert(res)
print(st1)
st2=Replace(st1)
print(st2)