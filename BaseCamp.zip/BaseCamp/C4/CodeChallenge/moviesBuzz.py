class Movie:
    def __init__(self,id,name,rating,type,collection):
        self.id=id
        self.name=name
        self.rating=rating
        self.type=type
        self.collection=collection

    def display(self):
        print("MovieId= {}\nName= {}\nRating= {}\nType= {}\nCollection={}\n".format(self.id,self.name,self.rating,self.type,str(self.collection)+"cr"))

class MovieBox:
    moviebox=[]
    def __init__(self):
        pass

    def addMovie(self):
        n=int(input("Enter Number of Movies"))
        for i in range(n):
            mid=int(input("Enter Movie ID"))
            mname=input("Enter Movie Name")
            mrating=float(input("Enter Movie Rating"))
            mtype=input("Enter Movie Type")
            mcollection=float(input("Enter Collection"))
            print()
            self.moviebox.append(Movie(mid,mname,mrating,mtype,mcollection))

    def displayRating(self):
        for i in range(len(self.moviebox)):
            if(self.moviebox[i].rating>=3.5 and self.moviebox[i].rating<=5):
                self.moviebox[i].display()

    def displayComdeyOneCR(self):
        for i in range(len(self.moviebox)):
            if(self.moviebox[i].collection<=1 and self.moviebox[i].type=="Comedy"):
                self.moviebox[i].display()

    def displayTopCollection(self):
        for i in range(len(self.moviebox)):
            for j in range(len(self.moviebox)-i-1):
                if(self.moviebox[j].collection < self.moviebox[j+1].collection):
                    self.moviebox[j],self.moviebox[j+1]=self.moviebox[j+1],self.moviebox[j]
        if(len(self.moviebox)>5):
            for i in range(5):
                self.moviebox[i].display()
        else:
            self.moviebox[i].display()

while True:
    m=MovieBox()
    print("1-ADD MOVIEZ\n2-Display MOVIES with Rating\n3-Comedy Movie with Box office 1 CR\n4-Top 5 BlockBuster Collections\n5-Exit")
    ch=int(input("Enter Your Choice.."))
    if(ch==1):
        m.addMovie()
    elif(ch==2):
        m.displayRating()
    elif(ch==3):
        m.displayComdeyOneCR()
    elif(ch==4):
        m.displayTopCollection()
    elif(ch==5):
        exit()


