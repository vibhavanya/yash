class Movie:
    def __init__(self,id,name,rating,type,collection):
        self.id=id
        self.name=name
        self.rating=rating
        self.type=type
        self.collection=collection

    def display(self):
        print("MovieId= {}\nName= {}\nRating= {}\nType= {}\nCollection={}\n".format(self.id,self.name,self.rating,self.type,str(self.collection)+"cr"))

#m=Movie(1,"RRR",5,"Action",2500)
#m.display()
moviebox=[]
def addMovie():
    n=int(input("Enter Number of Movies"))
    for i in range(n):
        mid=int(input("Enter Movie ID"))
        mname=input("Enter Movie Name")
        mrating=float(input("Enter Movie Rating"))
        mtype=input("Enter Movie Type")
        mcollection=float(input("Enter Collection"))
        print()
        moviebox.append(Movie(mid,mname,mrating,mtype,mcollection))

#addMovie()
#moviebox[0].display()

def displayRating():
    for i in range(len(moviebox)):
        if(moviebox[i].rating>=3.5 and moviebox[i].rating<=5):
            moviebox[i].display()
#addMovie()
#displayRating()

def displayComdeyOneCR():
    for i in range(len(moviebox)):
        if(moviebox[i].collection<=1 and moviebox[i].type=="Comdey"):
            moviebox[i].display()

def displayTopCollection(l):
    for i in range(len(l)):
        for j in range(len(l)-i-1):
            if(l[j].collection < l[j+1].collection):
                l[j],l[j+1]=l[j+1],l[j]
    if(len(moviebox)>5):
        for i in range(5):
            l[i].display()
    else:
        l[i].display()

