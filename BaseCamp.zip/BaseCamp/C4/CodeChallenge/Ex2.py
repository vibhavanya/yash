def adjacentSum(l):
    res=[]
    le=len(l)
    #print(le)
    for i in range(0,len(l)-1,2):
        sum=l[i]+l[i+1]
        res.append(sum)
    if(le%2!=0):
        res.append(l[len(l)-1])
    return res

def Sum10(l):
    cnt=0
    for i in l:
        if(i>10):
            cnt+=1
    return cnt
l=[]
n=int(input("Enter the Size of Array"))
for i in range(n):
    l.append(int(input()))
res=adjacentSum(l)
print(res)
print(Sum10(res))