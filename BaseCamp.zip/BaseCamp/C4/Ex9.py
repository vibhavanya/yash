class Employee:
    def __init__(self,id=0,name="Null",dept="Null",sal=0):
        self.id=id
        self.name=name
        self.dept=dept
        self.sal=sal
    def displayEmployee(self):
        print("-------------Mindtree Mind------------------")
        print("Employee Details:")
        print("EmployeeID= {}\nEmployeeName= {}\nEmployeeSalary= {}\nEmployeeDepartment= {}\n".format(self.id,self.name,self.sal,self.dept))
        print("-------------------------------------------")


emp=[]
def addEmployee():
    r=int(input("\t Enter Number of Employees"))
    for i in range(r):
        eid=int(input("\t\t->Enter Employee ID: "))
        ename=input("\t\t->Enter Name: ")
        esal=input("\t\t->Enter Salary: ")
        edept=input("\t\t->Enter Department: ")
        print()
        emp.append(Employee(eid,ename,edept,esal))

def SortNames(l):
    for i in range(len(l)):
        for j in range(len(l)-i-1):
            if(l[j].name > l[j+1].name):
                l[j],l[j+1]=l[j+1],l[j]

def SortEmpID(l):
    for i in range(len(l)):
        for j in range(len(l)-i-1):
            if(l[j].id > l[j+1].id):
                l[j],l[j+1]=l[j+1],l[j]



def displaySal(l):
    for i in range(len(l)):
        if(int(emp[i].sal)>50000):
            emp[i].displayEmployee()


while True:
    print("1-Add Employee Details\n2-Display Employee Details Based on Sorted Names\n3-Display Employee ID in Ascending Order\n4-Display Salary Greater than 50000\n5-Exit\n")
    print("--------Enter Your Choice--------")
    ch=int(input())
    if(ch==1):
        addEmployee()
    elif(ch==2):
        SortNames(emp)
        for k in range(len(emp)):
            emp[k].displayEmployee()
    elif(ch==3):
        SortEmpID(emp)
        for k in range(len(emp)):
            emp[k].displayEmployee()

    elif(ch==4):
        displaySal(emp)
    elif(ch==5):
        exit()
