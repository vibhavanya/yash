class Employee:
    def __init__(self,id=0,name="Null",desig="Null",dept="Null"):
        self.id=id
        self.name=name
        self.desig=desig
        self.dept=dept

    def setId(self,id):
        self.id=id
    def setName(self,name):
        self.name=name
        if(self.name==""):
            print("Error Name")
            exit()
    def setDesig(self,desig):
        self.desig=desig
        if(self.desig=="developer" or self.desig=="tester" or self.desig=="Lead" or self.desig=="manager"):
            pass
        else:
            print("Invalid Designation")
            exit()
    def setDept(self,dept):
        self.dept=dept
        if(self.dept=="TTH" or self.desig=="RCM" or self.dept=="Digital" or self.dept=="DevOps"):
            pass
        else:
            print("Invalid Department")
            exit()
    def displayEmployee(self):
        print("-------------Mindtree Mind------------------")
        print("Employee Details:")
        print("EmployeeID={}\nEmployeeName={}\nEmployeeDesignation={}\nEmployeeDepartment={}\n".format(self.id,self.name,self.desig,self.dept))
        print("-------------------------------------------")
while True:
    e2=Employee()
    eid=int(input("Enter Employee ID: "))
    e2.setId(eid)
    ename=input("Enter Name: ")
    e2.setName(ename)
    edesig=input("Enter Designation: ")
    e2.setDesig(edesig)
    edept=input("Enter Department: ")
    e2.setDept(edept)
    e2.displayEmployee()
    ch=input("Do you Want to Continue...[Y/N]")
    if(ch=='y' or ch=='Y'):
        pass
    else:
        print("Thank You!!!")
        exit()
