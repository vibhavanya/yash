class Account:
    def __init__(self,balance,intrestRate,accountNo):
        self.balance=balance
        self.intrestRate=intrestRate
        self.accountNo=accountNo

    def displayData(self):
        print("Balance= {}\nIntrest Rate= {}\nAccount Number={}\n".format(self.balance,self.intrestRate,self.accountNo))

    def withDraw(self,amount):
        if(amount>self.balance):
            print("Error Withdrawl")
        else:
            self.balance-=amount
            self.displayData()

obj=Account(1000,10,"SBI001")
amount=int(input("Enter Amount"))
obj.withDraw(amount)

