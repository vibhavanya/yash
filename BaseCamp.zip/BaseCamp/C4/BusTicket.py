def splitDate(a,dem):
    word=[]
    cnt=0
    for i in range(len(a)):
        if(a[i]==dem):
            word.append(a[cnt:i])
            cnt=i+1
    word.append(a[cnt:len(a)])
    return word

class BookTicket:
    def __init__(self,name,number,source,destination,date,time):
        self.name=name
        self.number=number
        self.source=source
        self.destination=destination
        self.date=date
        self.time=time

    def Display(self):
        print("Name: {}\nNumber:{}\nSource: {}\nDestination: {}\nDate :{}\nTime: {}".format(self.name,self.number,self.source,self.destination,self.date,self.time))

ticket=[]

def datecheck(cdate,bdate):
    flag=0
    b=splitDate(bdate,"/")
    c=splitDate(cdate,"/")
    bday=int(b[0])
    bmonth=int(b[1])
    byear=int(b[2])
    cday=int(c[0])
    cmonth=int(c[1])
    cyear=int(c[2])
    if((byear-cyear)==0 or (byear-cyear)==1):
        if((bmonth-cmonth)==-11 or abs(bmonth-cmonth)==0):
            if(abs(bday-cday)>=1 and abs(bday-cday)<=30):
                flag=1

    if(flag==1):
        return True
    else:
        return False


def ValidateTicket():
    cid=int(input("Enter Customer ID"))
    number=int(input("Enter Mobile Number"))
    src=input("Enter Source")
    dest=input("Enter Destination")
    time=input("Enter Time")
    ticket.append(BookTicket(cid,number,src,dest,time))
    #if(number==ticket[0].number)
    #if(ticket[0].source==ticket[0].destination):
    #if(datecheck(time)
    return True
#ValidateTicket()
print(datecheck("10/12/2019","9/1/2020"))

