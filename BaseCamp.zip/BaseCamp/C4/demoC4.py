
class Account:
    def __init__(self,id,name):
        self.id=id
        self.name=name
    def setBalance(self,balance):
        self.balance=balance
    def getBalance(self):
        return self.balance
    def Display(self):
        print(self.id+" "+self.name+" "+str(self.getBalance()))

obj1=Account("SBI123","K RAM")
obj2=Account("HDFC123","ABC")
#print(obj1.id)
#print(obj1.name)
obj1.setBalance(100000)
#print(obj1.getBalance())
#print(obj2.id)
#print(obj2.name)
obj2.setBalance(500000)
#print(obj2.getBalance())
obj1.Display()
obj2.Display()