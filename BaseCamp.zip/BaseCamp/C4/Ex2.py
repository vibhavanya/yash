class Book:
    def __init__(self,author="Daniel Defoe",bookName="Robinson Crusoe",price="$15.50",year="1719"):
        self.author=author
        self.bookName=bookName
        self.price=price
        self.year=year

    def Display(self):
        print("---------bOOkStOre----------")
        print("Book Author={}\nBook Name={}\nPrice={}\nYear of Publication={}\n".format(self.author,self.bookName,self.price,self.year))
        print("----------------------------")

n=int(input("Enter Number of Books you Want to Enter"))
book=[]
for i in range(n):
    bAuthor=input("Enter Author Name: ")
    bName=input("Enter BOOK NAME: ")
    bprice=input("Enter Price: ")
    byear=input("Enter Year Of Publication: ")
    book.append(Book(bAuthor, bName, '$' + bprice, byear))
    print()
for i in range(n):
    book[i].Display()

search=input("Enter Book Name to Search")
for i in range(n):
    if(book[i].bookName==search):
        book[i].Display()
    else:
        flag=0
if(flag==0):
    print("Book Not Found")
