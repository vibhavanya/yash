'''
def reverse(st):
    return st[::-1]

def sentence(st):
    l1=[]
    l=st.split(' ')
    for i in l:
        if((i.isdigit())==True):
            l1.append(i)
        else:
            l1.append(reverse(i))
    return ' '.join(l1)

print(sentence("Ram100 is Good"))


st="Ram100 sai rs3"
temp=""
temp1=""
temp2=""
l=[]
def rev(st):
    for i in range(0,len(st)):
        if st[i].isdigit():
            temp+=st[i]
            print(temp)
        else:
            temp1+=st[i]
        temp2=temp1[ : :-1]
        print(temp2)

'''
def rev(st):
    temp=""
    temp1=""
    temp2=""
    for i in range(0,len(st)):

        # if st[i].isdigit():
        #     temp+=st[i]
            #print(temp)

        if(ord(st[i])>=32 and ord(st[i])<=64):
            temp+=st[i]

        else:
            temp1+=st[i]
            temp2=temp1[ : :-1]
    return(temp2+temp)

st1=""
st="my Name. is, @p& Max.132aisj8273"
l=st.split(" ")
for i in l:
    st1=st1+rev(i)+" "
print(st1)
