l1=[]
l2=[]
l=[]

n1=int(input())
n2=int(input())
for i in range(n1):
    l1.append(int(input()))
for i in range(n2):
    l2.append(int(input()))
l=l1+l2
print(l)
def countEle(l,ele):
    cnt=0
    for i in l:
        if(i==ele):
            cnt+=1
    if(cnt!=0):
        return cnt

for i in range(len(l)):
    if((countEle(l,l[i]))==1):
        print(l[i])

#print(countEle(l,3))




