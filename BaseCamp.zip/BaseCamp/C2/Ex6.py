def computeInitials(name):
  n=name.split(" ")
  st=""
  for i in n:
  	st=st+i[0]
  return st

#print(computeInitials("K RAM SAI"))
print(computeInitials(input("Enter Name")))