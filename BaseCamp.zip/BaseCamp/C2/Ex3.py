def getMax(a,b,c):
  if(a>b and a>c):
    max=a
  elif(b>c and b>a):
    max=b
  else:
    max=c
  return max

num1=int(input())
num2=int(input())
num3=int(input())
print(getMax(num1,num2,num3))