def changeName(st1,st2):
    l1=st1.split(" ")
    l2=st2.split(" ")
    temp=l1[len(l1)-1]
    l1[len(l1)-1]=l2[len(l2)-1]
    l2[len(l2)-1]=temp
    st1=' '.join(l1)
    st2=' '.join(l2)
    return st1,st2
print(changeName(input(),input()))
