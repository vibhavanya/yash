import math
def isPrime(n):
    cnt=0
    for i in range(2,int(math.sqrt(n))):
        if(n%i)==0:
            cnt+=1
    if(cnt==0):
        return True
    else:
        return False

num=int(input())
print(isPrime(num))