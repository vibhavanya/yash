col=int(input())
row=int(input())
a=[[int(input()) for i in range(col)] for j in range(row)]
b=[[int(input()) for i in range(col)] for j in range(row)]
print(a)
print(b)
c=[[a[i][j]+b[i][j] for j in range(col)] for i in range(row)]
print(c)



