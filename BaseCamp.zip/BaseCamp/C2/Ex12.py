def stringLower(st):
    st1=""
    res=""
    l=[]
    for i in st:
        if(i>='A' and i<='Z'):
            st1+=chr(ord(i)+32)
        if(i>='a' and i<='z'):
            st1+=i
    return st1
def stringCompress(st):
    temp=st[0]
    cnt=1
    res1=""
    for i in range(1,len(st)):
        if(st[i]==temp):
            cnt+=1
        else:
            res=temp+str(cnt)
            res1+=res
            temp=st[i]
            cnt=1
    res=temp+str(cnt)
    res1+=res
    return res1

st=input()
st=stringLower(st)
print(stringCompress(st))