l1=[]
l2=[]
l3=[]

n1=int(input("Enter size of Array1"))
n2=int(input("Enter size of Array2"))
for i in range(n1):
    l1.append(float(input()))
for j in range(n2):
    l2.append(float(input()))
print(l1)
print(l2)
if(len(l1)>len(l2)):
    st=len(l1)-len(l2)
    for i in range(0,st):
        l2.append(0)

for i in range(0,len(l1)):
    l3.append(l1[i]+l2[i])

print(l3)

