col=int(input())
row=int(input())
a=[[int(input()) for i in range(col)] for j in range(row)]
#b=[[int(input()) for i in range(col)] for j in range(row)]
print(a)
#print(b)
#c=[[a[i][j]+b[i][j] for j in range(col)] for i in range(row)]

'''
cnt=False
sum=0
for j in range(col):
    sum+=a[0][j]
for i in range(1,row):
    newsum=0
    for j in range(col):
        newsum+=a[i][j]
    if(newsum!=sum):
        cnt=False
    else:
        cnt=True
if(cnt==True):
    print("True::")
'''
def rowMagic(a):
    cnt=False
    sum=0
    for j in range(col):
        sum+=a[0][j]
    for i in range(1,row):
        newsum=0
        for j in range(col):
            newsum+=a[i][j]
        if(newsum!=sum):
            cnt=False
        else:
            cnt=True
    if(cnt==True):
        print("True:Its Magic Row")

rowMagic(a)
