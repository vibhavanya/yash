l=[]
sum=0
n=int(input("Enter size of an Array"))
for i in range(0,n):
  l.append(int(input()))
for i in l:
  sum+=i
print(sum)