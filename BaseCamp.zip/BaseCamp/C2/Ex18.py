mark=[]
n=int(input())
while(n!=0):
    m=int(input("Enter marks in Range 0 to 25)"))
    if(m>=0 and m<=25):
        mark.append(m)
        n-=1
    else:
        print("Mark should be in Range 0 to 25")

def countMark(l,ele):
    cnt=0
    for i in l:
        if(i==ele):
            cnt+=1
    return cnt

cnt=int(input("Enter Number to see how many student obtained certain marks"))
print("Number of students obtained specific marks::{}".format(countMark(mark,cnt)))
