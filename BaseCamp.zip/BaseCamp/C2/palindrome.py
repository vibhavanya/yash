def PalindromeNumber(a):
    rev=0
    temp=a
    while(a>0):
        rem=a%10
        rev=rev*10+rem
        a=a//10
    if(temp==rev):
        return True
    else:
        return False
def PalindromeString(b):
    st=""
    temp=b
    for i in range(len(b)-1,-1,-1):
        st+=b[i]
    if(temp==st):
        return True
    else:
        return False
num=int(input("Enter a Number"))
print(PalindromeNumber(num))
st=input("Enter a String")
print(PalindromeString(st))