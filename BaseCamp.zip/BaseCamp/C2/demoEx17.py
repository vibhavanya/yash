col=int(input())
row=int(input())
a=[[int(input()) for i in range(col)] for j in range(row)]

def rowMagic(a):
    cnt=False
    sum=0
    for j in range(col):
        sum+=a[0][j]
    for i in range(1,row):
        newsum=0
        for j in range(col):
            newsum+=a[i][j]
        if(newsum!=sum):
            cnt=False
        else:
            cnt=True
    return cnt

def colMagic(a):
    cnt=False
    sum=0
    for j in range(col):
        sum+=a[j][0]
    #print(sum)
    for i in range(1,col):
        newsum=0
        for j in range(row):
            newsum+=a[j][i]
        #print(newsum)
        if(newsum!=sum):
            cnt=False
        else:
            cnt=True
    return cnt


def diagonalMagic(a):
    cnt=False
    sum=0
    sum1=0
    for i in range(row):
        for j in range(col):
            if(i==j):
                sum=sum+a[i][j]
            if(i+j==row-1):
               sum1+=a[i][j]
    if(sum==sum1):
        return True
    else:
        return False


if(rowMagic(a)==True and colMagic(a)== True and diagonalMagic(a)==True):
    print("Magic Array")
else:
    print("Not an Magic Array")
