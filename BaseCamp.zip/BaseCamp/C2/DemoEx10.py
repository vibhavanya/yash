
st=input("Enter a String")
if(len(st)==10):
    if(st[0]=='1' or st[0]=='2'):
        if((st[1]>='A' and st[1]<='Z')and(st[2]>='A' and st[2]<='Z')):
            if((ord(st[3])>=48 and ord(st[3])<=57)and(ord(st[4])>=48 and ord(st[4])<=57)):
                if((st[5]>='A' and st[5]<='Z') and (st[6]>='A' and st[6]<='Z') and (st[5:7]=='CS' or st[5:7]=='IS' or st[5:7]=='EC' or st[5:7]=='ME')):
                    if((ord(st[7])>=48 and ord(st[7])<=57) or (ord(st[8])>=48 and ord(st[8])<=57) or (ord(st[9])>=48 and ord(st[9])<=57)):
                        print("Successs")
                    else:
                        print("Failure")

                else:
                    print("Failure")
            else:
                print("Failure")
        else:
            print("Failure")
    else:
        print("Failure")
else:
    print("Failure")

