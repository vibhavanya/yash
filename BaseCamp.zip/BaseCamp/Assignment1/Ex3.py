l=[]
n=int(input())
if(n>0):
    for i in range(n):
        st=input()
        l.append(st)
else:
    print("Invalid")

#print(l)

cnt=0
for i in l:
    cnt+=1
    print("{}.{}".format(cnt,i))
