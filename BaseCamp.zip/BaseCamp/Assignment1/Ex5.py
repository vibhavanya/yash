
def fill(l):
    s=[0 for i in range(11)]
    for i in range(len(l)):
        s[i]=l[i]+s[i]
    return s
l=[]
r=int(input())
for i in range(r):
    inp=int(input())
    if(inp>=0):
        l.append(inp)
    else:
        print("Invalid")
        exit()
l=fill(l)
for i in range(len(l)):
    print(l[i])