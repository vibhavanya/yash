def specialNumber(n):
    temp=n
    n2=n%10
    n1=n//10
    #n1=n%10
    sum=n1+n2
    product=n1*n2
    res=sum+product
    if(res==temp):
        return res
    else:
        return False

r1=int(input())
r2=int(input())
if(r1>=10 and r1<100)or(r2>=10 and r2<100):
    for i in range(r1,r2+1):
        if(specialNumber(i)!=False):
            print("{} ".format(specialNumber(i)))
else:
    print("Range Must Two Digit Number:")

