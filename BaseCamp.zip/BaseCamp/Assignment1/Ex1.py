def trendyNumber(n):
    cnt=0
    while(n>0):
        cnt+=1
        rem=n%10
        if(cnt==2):
            rem1=n%10
        n=n//10
    if(cnt==3 and rem1%3==0):
        print("Trendy Number!!")
    else:
        print("Not an Trendy Number!!")

def count(s):
    l=len(str(s))
    return l


number=int(input("Enter an Number:"))
if(number>0 and count(number)==3):
    trendyNumber(number)
else:
    print("Please Enter positive Three Integer Number:")
