def compare(l1,l2):
    flag=0
    for i in range(len(l1)):
        if(l1[i]==l2[i]):
            flag+=1
    if(flag==len(l1)):
        print("Same")
    else:
        print("Different")

dhoni=[]
sangakara=[]
stat=4 #int(input("Enter Number of Stastistic:"))
for i in range(stat):
    n=int(input())
    if(n>0):
        dhoni.append(n)
    else:
        print("Invalid Input")
        exit()
for j in range(stat):
    m=int(input())
    if(m>0):
        sangakara.append(m)
    else:
         print("Invalid Input")
         exit()
#print(dhoni)
#print(sangakara)
compare(dhoni,sangakara)
