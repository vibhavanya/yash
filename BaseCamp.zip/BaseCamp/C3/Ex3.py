def binarySearchElement(b,key):
    l=0
    h=len(b)-1

    while(l<=h):
        mid=(h+l)//2
        if(b[mid]>key):
            h=mid-1
        elif(b[mid]<key):
            l=mid+1
        elif(b[mid]==key):
            return True
    else:
        return False

def binarySearchString(b,key):
    l=0
    h=len(b)-1

    while(l<=h):
        mid=(h+l)//2
        if(b[mid]>key):
            h=mid-1
        elif(b[mid]<key):
            l=mid+1
        elif(b[mid]==key):
            return True
    else:
        return False
while(1):
    print("1-Binary Search for Integer Elements\n2-Binary Search for Strings\n3-Exit\n")
    ch=int(int(input("Enter Your Choice")))
    if(ch==1):
        l=[]
        n=int(input("Enter Range"))
        for i in range(n):
            l.append(int(input()))
        l.sort()
        key=int(input())
        #binarySearchElement(l,key)
        print("Output: {}".format(binarySearchElement(l,key)))
    elif(ch==2):
        l=[]
        n=int(input("Enter Range"))
        for i in range(n):
            l.append(input())
        l.sort()
        key=input()
        print("Output: {}".format(binarySearchString(l,key)))
    elif(ch==3):
        exit()

