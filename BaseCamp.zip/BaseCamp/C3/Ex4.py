def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key
import array
l=[]
arr=array.array('i',l)
n=int(input())
for i in range(n):
    ele=int(input())
    arr.append(ele)
print(arr)
insertionSort(arr)
print(arr)