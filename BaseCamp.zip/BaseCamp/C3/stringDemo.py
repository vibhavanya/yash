def splitString(a,dem):
    word=[]
    cnt=0
    for i in range(len(a)):
        if(a[i]==dem):
            word.append(a[cnt:i])
            cnt=i+1
    word.append(a[cnt:len(a)])
    return word

'''
def reverseWord(st):
    return st[::-1]
st=input("Enter a String")
l=splitString(st," ")

res=""
for i in range(len(l)):
    if((i+1)%2)==0:
        l[i]=reverseWord(l[i])
    else:
        pass
for i in l:
    res+=i
    res+=" "
print(res)
'''
l=splitString("1/10/2019 aa bb cc","/")
print(l)