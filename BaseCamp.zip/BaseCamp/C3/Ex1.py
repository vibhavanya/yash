'''
res=[[0,0],[0,0]]
row=2
for i in range(row):
    for j in range(row):
        res[i][j]=int(input())
print(res)
temp=[]
temp1=[]
for i in range(row):
    for j in range(row):
        if(i==j):
            temp.append(res[i][j])
        elif(i+j==row-1):
            temp1.append(res[i][j])

print(temp)
print(temp1)

for i in range(row):
    for j in range(row):
        if(i==j):
            res[i][j]=temp1[j]
        elif(i+j==row-1):
            res[j][i]=temp[j]

print(res)
'''
import array
l=[]
arr=array.array('i',l)
n=int(input())
for i in range(n):
    ele=int(input())
    arr.append(ele)
print(arr)
def BubbleSort(l):
    for i in range(len(l)):
        for j in range(len(l)-i-1):
            if(l[j]>l[j+1]):
                l[j],l[j+1]=l[j+1],l[j]

BubbleSort(arr)
#print(arr)
for i in range(n):
    print(arr[i],end=" ")