def linearSearch(l,key):
    flag=0
    for i in l:
        if(i==key):
            flag=1
        else:
            flag=0
    if(flag==1):
        return True
    else:
        return False

l=[]
n=int(input("Enter the range::"))
for i in range(n):
    l.append(int(input()))
key=int(input("Enter Key:"))
print(linearSearch(l,key))
