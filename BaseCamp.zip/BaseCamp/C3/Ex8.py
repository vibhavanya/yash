def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key
l=int(input("Enter Number of List"))
r=int(input("Enter Element into List"))

a=[[int(input()) for i in range(r)] for j in range(l)]
#print(a)

s=[]
for i in range(l):
    for j in range(r):
        s.append(a[i][j])
print(s)
insertionSort(s)
print(s)