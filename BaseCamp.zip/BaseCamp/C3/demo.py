
def splitString(st,dem):
    word=[]
    cnt=0
    for i in range(len(a)):
        if(a[i]==dem):
            word.append(a[cnt:i])
            cnt=i+1
    word.append(a[cnt:len(a)])
    return word

def stringLower(st):
    st1=""
    res=""
    for i in st:
        if(i>='A' and i<='Z'):
            st1+=chr(ord(i)+32)
        if(i>='a' and i<='z'):
            st1+=i
    return st1
def count(st,key):
    cnt=0
    for i in st:
        if(i==key):
            cnt+=1
    return cnt
a=input("Enter String")
l=splitString(a," ")
word=[]
