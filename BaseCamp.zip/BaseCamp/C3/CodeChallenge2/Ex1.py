def updatePurchase(fruits,purchase):
    fruits[fruit]+=purchase
    return fruits[fruit]


def displayFruits(l):
    res=sorted(l.items(),key=lambda kv:(kv[1],kv[0]))
    for i in range(len(l)-1,-1,-1):
        print("{}.{} -  {}".format((len(l))-i,res[i][0],res[i][1]))


l={"Mango":0,"Apple":0,"Orange":0,"Pear":0}

while 1:
    print("1-Update Purchase\n2-Display Fruit List\n3-Exit")
    ch=int(input("Enter Your Choice"))

    if(ch==1):
        fruit=input("Enter Fruit")
        if(fruit not in l):
            l.update({fruit:0})
        cnt=int(input("Enter Quantity"))
        if(cnt>0):
            print(updatePurchase(l,cnt))
        else:
            print("Purchase Cannot be Negative.")
    elif(ch==2):
        print("--------------------")
        print("Fruits::")
        displayFruits(l)
        print("--------------------")
    elif(ch==3):
        exit()
