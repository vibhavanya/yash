def count(st,key):
    cnt=0
    for i in st:
        if(i==key):
            cnt+=1
    return cnt
def linearSearch(l,key):
    for i in range(len(l)):
        if(l[i]==key):
            return i+1
            break


l=[]
n=int(input())
for i in range(n):
    l.append(int(input()))
sEle=int(input())
if(count(l,sEle)==1):
    print(linearSearch(l,sEle))
else:
    print("Invalid")