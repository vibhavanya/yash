def insertionSort(l):
    for i in range(1,len(l)):
        key=l[i]
        j=i-1
        while(j>=0 and l[j]>key):
            l[j+1]=l[j]
            j=j-1
        l[j+1]=key

def BubbleSort(l):
    for i in range(len(l)):
        for j in range(len(l)-i-1):
            if(l[j]>l[j+1]):
                l[j],l[j+1]=l[j+1],l[j]

def binarySearchString(b,key):
    l=0
    h=len(b)-1
    while(l<=h):
        mid=(h+l)//2
        if(b[mid]>key):
            h=mid-1
        elif(b[mid]<key):
            l=mid+1
        elif(b[mid]==key):
            return True
    else:
        return False

while(1):
    print("1.Sort Using Bubble Sort\n2.Sort Using Insertion Sort\n3.Search an String\n4.Exit")
    ch=int(input("Enter Your Choice"))
    if(ch==1):
        l=[]
        r=int(input())
        for i in range(r):
            l.append(input())
        BubbleSort(l)
        print("Array Sorted using BubbleSort")
        print(l)
    elif(ch==2):
        l=[]
        r=int(input())
        for i in range(r):
            l.append(input())
        insertionSort(l)
        print("Array Sorted using InsertionSort")
        print(l)
    elif(ch==3):
        l=[]
        r=int(input())
        for i in range(r):
            l.append(input())

        insertionSort(l)
        key=input("Enter Key")
        print(binarySearchString(l,key))
    elif(ch==4):
        exit()

