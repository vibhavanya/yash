def max(l):
    max=l[0]
    for i in range(1,len(l)):
        if(l[i]>max):
            max=l[i]

    return max

l=[]
res=[]
n=int(input("Enter Array Length"))
for i in range(n):
    l.append(int(input()))
print("Enter the Range::")
n1=int(input(""))
n2=int(input(""))
if(n1>=0 or n2>0):
    for i in range(n1,n2+1):
        res.append(l[i])
else:
    print("Invalid Range")
    exit()
print(max(res))